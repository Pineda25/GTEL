var SeccionesModelos = require("../models/SeccionesModelos");

class SeccionesControladores{
  todos() {
    return new Promise((resolve, reject) => {   
      //resolve(SeccionesModelos.todos());
      let prueba= SeccionesModelos.todos();
        if(prueba){
          resolve(prueba);
        } else {
          reject(new Error("Ha ocurrido un error"));
        }
    })
  }
  uno(idReq) {
    return new Promise((resolve,reject)=>{
      //resolve(SeccionesModelos.uno(idReq))
      let prueba= SeccionesModelos.uno(idReq);
        if(prueba){
          resolve(prueba);
        } else {
          reject(new Error("Ha ocurrido un error"));
        }

    })
  }
  crear(usuario){
    return new Promise((resolve, reject) =>{
        //resolve(SeccionesModelos.crear(usuario));
        let prueba= SeccionesModelos.crear(usuario);
        if(prueba){
          resolve(prueba);
        } else {
          reject(new Error("Ha ocurrido un error"));
        }
      
  })
    
  }
  modificar(idReq, nuevoNombre){
    return new Promise((resolve, reject) => {   
      //resolve(SeccionesModelos.modificar(idReq, nuevoNombre));
      let prueba= SeccionesModelos.modificar(idReq, nuevoNombre);
        if(prueba){
          resolve(prueba);
        } else {
          reject(new Error("Ha ocurrido un error"));
        }
    })

  }
  eliminar(idElemento){
    return new Promise((resolve, reject) =>{
      //resolve(SeccionesModelos.eliminar(idElemento));
      let prueba= SeccionesModelos.eliminar(idElemento);
        if(prueba){
          resolve(prueba);
        } else {
          reject(new Error("Ha ocurrido un error"));
        }

    })
  }
  }


module.exports = new SeccionesControladores();
