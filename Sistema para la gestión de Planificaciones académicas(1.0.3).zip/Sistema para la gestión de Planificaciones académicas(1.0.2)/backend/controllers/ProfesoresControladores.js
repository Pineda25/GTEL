var ProfesoresModelos = require("../models/ProfesoresModelos");

class ProfesoresControladores{
  todos() {
    return new Promise((resolve, reject) => {   
     //resolve(ProfesoresModelos.todos());
     let prueba= ProfesoresModelos.todos();
        if(prueba){
          resolve(prueba);
        } else {
          reject(new Error("Ha ocurrido un error"));
        }
    })
  }
  uno(idReq) {
    return new Promise((resolve,reject)=>{
      //resolve(ProfesoresModelos.uno(idReq))
      let prueba= ProfesoresModelos.uno(idReq);
        if(prueba){
          resolve(prueba);
        } else {
          reject(new Error("Ha ocurrido un error"));
        }

    })
  }
  crear(usuario){
    return new Promise((resolve, reject) =>{
        //resolve(ProfesoresModelos.crear(usuario));
        let prueba= ProfesoresModelos.crear(usuario);
        if(prueba){
          resolve(prueba);
        } else {
          reject(new Error("Ha ocurrido un error"));
        }
      
  })
    
  }
  modificar(idReq, nuevoNombre){
    return new Promise((resolve, reject) => {   
      //resolve(ProfesoresModelos.modificar(idReq, nuevoNombre));
      let prueba= ProfesoresModelos.modificar(idReq,nuevoNombre);
        if(prueba){
          resolve(prueba);
        } else {
          reject(new Error("Ha ocurrido un error"));
        }
    })

  }
  eliminar(idElemento){
    return new Promise((resolve, reject) =>{
      //resolve(ProfesoresModelos.eliminar(idElemento));
      let prueba= ProfesoresModelos.eliminar(idElemento);
        if(prueba){
          resolve(prueba);
        } else {
          reject(new Error("Ha ocurrido un error"));
        }

    })
  }
  }


module.exports = new ProfesoresControladores();
