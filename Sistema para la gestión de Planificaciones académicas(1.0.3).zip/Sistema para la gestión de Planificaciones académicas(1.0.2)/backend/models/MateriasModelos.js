let MateriasArr = [
    {
        nombre:"Matematicas",
        id:"1",

    }
]


class MateriasModelos{
    todos(){
        return MateriasArr
    }
    uno(idReq) {
    
        for(let i=0;i<MateriasArr.length;i++){
          if(idReq==MateriasArr[i].id){
            return MateriasArr[i]
          }
        }
    
      
    }
    crear(usuario){
      return new Promise((resolve, reject) => {
         // setTimeout (() => {
              usuario.id = uuidv4();
              MateriasArr.push(usuario);
              //resolve();
              if(usuario){
                resolve()
              } else {
                reject(new Error("Ha ocurrido un error"));
              }
        //  },1000)

          
      })
    }
   modificar(idReq, nuevoNombre) {
    return new Promise((resolve, reject) => {
      for (let i = 0; i < MateriasArr.length; i++) {
        if (idReq === MateriasArr[i].id) {
          MateriasArr[i].nombre = nuevoNombre;
          //resolve(MateriasArr[i]);
          if(nuevoNombre){
            resolve(MateriasArr[i]);
          } else {
            reject(new Error("Ha ocurrido un error"));
          }
        } 
      }
      ;
    });
  }
    
  eliminar(idElemento){
    for(let i=0;i<MateriasArr.length;i++){
      if(idElemento==MateriasArr[i].id){
        let index = MateriasArr.indexOf(idElemento)
        MateriasArr.splice(index,1);
      }
    }
  
  
  }
}
module.exports = new MateriasModelos