const { resolveInclude } = require('ejs');
const { v4: uuidv4 } = require ('uuid');

let ProfesoresArr = [
   {
    nombre: "Maria",
        materia: 1,
        eventos:[1,4,2],
        id:1,
        seccion:2
        
   }
]

class ProfesoresModelos{
  todos() {
    return ProfesoresArr;
  }
  uno(idReq) {
    
      for(let i=0;i<ProfesoresArr.length;i++){
        if(idReq==ProfesoresArr[i].id){
          return ProfesoresArr[i]
        }
      }
  
    
  }
  crear(usuario){
    //usuario.id = uuidv4();
    //ProfesoresArr.push(usuario);
    return new Promise((resolve, reject) => {
        setTimeout (() => {
            usuario.id = uuidv4();
            ProfesoresArr.push(usuario);
            resolve();
        },1000);
    })
  }
 modificar(idReq, nuevoNombre) {
  return new Promise((resolve, reject) => {
    for (let i = 0; i < ProfesoresArr.length; i++) {
      if (idReq === ProfesoresArr[i].id) {
        ProfesoresArr[i].nombre = nuevoNombre;
        resolve(ProfesoresArr[i]);
      }
    }
    ;
  });
}
  
eliminar(idElemento){
  for(let i=0;i<ProfesoresArr.length;i++){
    if(idElemento==ProfesoresArr[i].id){
      let index = ProfesoresArr.indexOf(idElemento)
      ProfesoresArr.splice(index,1);
    }
  }


}
}

module.exports = new ProfesoresModelos(); 