let Profesores= [
    {
        nombre: "Maria",
        materia: 1,
        eventos:[],
        id:"1",
        seccion:2
        
    }
]
let Materias = [
    {
        nombre:"Matematicas",
        id:"1",

    }
]
let Secciones = [
    {
        nombre: "VB1",
        id:2
    }
]
let Eventos = [
    {
        nombre: "Examen",
        fecha: "12 de Febrero",
        id:4
    }
]