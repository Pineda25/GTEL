var express = require('express');
var router = express.Router();
var ProfesoresControladores = require("../controllers/ProfesoresControladores");
let MateriasControladores = require("../controllers/MateriasControlador")

/* GET users listing. */
router.get('/profesores', function(req, res, next) {
  ProfesoresControladores.todos()
  .then((resultados) =>{
    res.send(resultados); 
  })
  .catch((e) => console.error(e.message));
});

router.get('/materias', function(req, res, next) {
   MateriasControladores.todos()
   .then((resultados) =>{
     res.send(resultados); 
   })
   .catch((e) => console.error(e.message));
 });

/* POST crear users. */
router.post('/profesores', function(req, res, next) {
  ProfesoresControladores.crear(req.body)
  .then(() => {
      ProfesoresControladores.todos()
      .then((resultados) =>{
      res.send(resultados); 
    })
  })
  .catch((e) => console.error(e.message));
});

router.post('/materias', function(req, res, next) {
  MateriasControladores.crear(req.body)
  .then(() => {
      materiasControladores.todos()
      .then((resultados) =>{
      res.send(resultados); 
    })
  })
  .catch((e) => console.error(e.message));
});

/* PUT modificar user */
router.put('/profesores/:id', function(req, res, next) {
  const idReq = req.params.id;
  const nuevoNombre = req.body.nombre;
  ProfesoresControladores.modificar(idReq, nuevoNombre)
    .then((usuarioActualizado) => {
      res.send(usuarioActualizado);
    })
    .catch((e) => console.error(e.message));
    });

    router.put('/materias/:id', function(req, res, next) {
      const idReq = req.params.id;
      const nuevoNombre = req.body.nombre;
      MateriasControladores.modificar(idReq, nuevoNombre)
        .then((usuarioActualizado) => {
          res.send(usuarioActualizado);
        })
        .catch((e) => console.error(e.message));
        });

/* GET one user  */
router.get("/profesores/:id",function(req,res,next){
  ProfesoresControladores.uno(req.params.id)
  .then((resultados)=>{
    res.send(resultados)
  })
  .catch((e) => console.error(e.message));
})

router.get("/materias/:id",function(req,res,next){
  MateriasControladores.uno(req.params.id)
  .then((resultados)=>{
    res.send(resultados)
  })
  .catch((e) => console.error(e.message));
})

router.delete("/profesores/:id",function(req,res,next){
ProfesoresControladores.eliminar(req.params.id)
  .then(()=>{
    ProfesoresControladores.todos()
    .then((resultados) =>{
    res.send(resultados);  }
  )})
    .catch((e) => console.error(e.message));
  })

  router.delete("/materias/:id",function(req,res,next){
    MateriasControladores.eliminar(req.params.id)
      .then(()=>{
        MateriasControladores.todos()
        .then((resultados) =>{
        res.send(resultados);  }
      )})
      .catch((e) => console.error(e.message));
      })
    
module.exports = router;
